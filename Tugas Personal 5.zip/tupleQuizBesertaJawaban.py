#   Created by Elshad Karimov on 23/04/2020.
#   Copyright © 2020 AppMillers. All rights reserved.

# Tuple Interview Questions



# Q-1. What will be the output of the following code block?

init_tuple = ()
print (init_tuple.__len__())
# C. 0

 

# Q-2. What will be the output of the following code block?

init_tuple_a = 'a', 'b'
init_tuple_b = ('a', 'b')

print (init_tuple_a == init_tuple_b)
# D. True
 

# Q-3. What will be the output of the following code block?

init_tuple_a = '1', '2'
init_tuple_b = ('3', '4')

print (init_tuple_a + init_tuple_b)
# B.  (‘1’, ‘2’, ‘3’, ‘4’)

 

# Q-4. What will be the output of the following code block?

init_tuple_a = 1, 2
init_tuple_b = (3, 4)

[print(sum(x)) for x in [init_tuple_a + init_tuple_b]]
# C. 10


 

# Q-5. What will be the output of the following code block?

init_tuple = [(0, 1), (1, 2), (2, 3)]
result = sum(n for _, n in init_tuple)

print(result)
# B. 6

 

# Q-6. Which of the following statements given below is/are true?
# D. All of them.

 

# Q-7. What will be the output of the following code block?

l = [1, 2, 3]
init_tuple = ('Python',) * (l.__len__() - l[::-1][0])

print(init_tuple)
# A. ()

 

# Q-8. What will be the output of the following code block?

init_tuple = ('Python') * 3

print(type(init_tuple))
# B. <class ‘str’>


 

# Q-9. What will be the output of the following code block?

init_tuple = (1,) * 3
init_tuple[0] = 2
print(init_tuple)
# D. TypeError: ‘tuple’ object does not support item assignment

 

# Q-10. What will be the output of the following code block?

init_tuple = ((1, 2),) * 7
print(len(init_tuple[3:8]))
# C. 4