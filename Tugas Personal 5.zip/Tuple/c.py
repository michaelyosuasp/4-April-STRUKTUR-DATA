#!/usr/bin/env python
# coding: utf-8

# In[1]:


myDict = dict()
print(myDict)


# In[2]:


secondDict = {}
print(secondDict)


# In[4]:


engToSp = {"one":"uno","two":"dos","three":"tres"}
print(engToSp)


# In[5]:


engToSp["one"]


# In[7]:


engToSp["three"]


# In[8]:


engToSp["four"]


# In[ ]:





# In[ ]:




